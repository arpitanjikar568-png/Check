# Arpit Jewelrys — Website

A premium jewellery showcase/catalogue site (no cart, no checkout, no payments).
Static HTML/CSS/JS front-end, product data and pricing driven by **Firebase
Realtime Database**, built to run entirely on the free **Spark** plan.

## What's in here

```
index.html          Home page (hero, categories, gallery, about, FAQs, contact)
earrings.html        Earrings catalogue (reads /products/earrings from Firebase)
necklace.html         Necklace catalogue (reads /products/necklaces from Firebase)
admin.html           Admin panel — update rates, add/edit/delete products
css/style.css         All styling (maroon / royal gold / off-white palette)
js/firebase-config.js Firebase project keys — fill this in first
js/pricing.js         Modular price calculation (shared by catalogue + admin)
js/products.js         Renders the catalogue pages from live Firebase data
js/admin.js            Auth-gated read/write logic for the admin panel
js/main.js             Homepage interactions (nav, FAQ accordion, gallery lightbox)
assets/images/         Placeholder SVG icons — swap these for real photography
```

**Note on the two things the brief mentioned but weren't attached to this
chat:** the detailed PRD and your product/hero photos. I built this against
the structure doc you pasted in; if the PRD has extra specifics, send it over
and I'll adjust. For images, every `<img>` currently points at a simple gold
line-art placeholder in `assets/images/` — drop your real photos into that
folder (or a URL field in the admin panel) with the same filenames, or update
the `src`/`image` values, and they'll appear everywhere automatically.

## 1. Create the Firebase project (free)

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → **Add project** → name it (e.g. `arpit-jewelrys`).
2. In the project, click the **</> (Web)** icon → register an app → copy the `firebaseConfig` object.
3. Paste those values into `js/firebase-config.js`.
4. In the left sidebar: **Build → Realtime Database → Create Database** → start in **locked mode**.
5. In the left sidebar: **Build → Authentication → Get started → Email/Password → Enable**.
6. Still in Authentication → **Users** tab → **Add user** → create yourself an admin login (this is the only account that should exist — there's no public sign-up).

You never need to upgrade to the Blaze plan for this project.

## 2. Set database rules

In **Realtime Database → Rules**, replace the default with:

```json
{
  "rules": {
    "products": {
      ".read": true,
      ".write": "auth != null"
    },
    "rates": {
      ".read": true,
      ".write": "auth != null"
    }
  }
}
```

This lets any visitor **read** the catalogue and rates (needed for the public
pages to work), but only a **signed-in admin** can write. Publish the rules.

## 3. Seed some starter data

In **Realtime Database → Data**, use the "+" button to build this structure
(or import it as JSON via the "⋮" menu → Import JSON):

```json
{
  "rates": {
    "gold22K": 7200,
    "gold18K": 5900,
    "silver": 95
  },
  "products": {
    "earrings": {
      "sample1": {
        "name": "Rani Jhumka",
        "purity": "22K",
        "weight": 6.4,
        "makingChargeType": "percentage",
        "makingCharge": 12,
        "otherCharges": 150,
        "wastagePercent": 4,
        "image": "assets/images/placeholder-earring.svg",
        "description": "Traditional jhumka with a fine antique finish.",
        "available": true
      }
    },
    "necklaces": {}
  }
}
```

Once real data exists you can manage everything from `admin.html` instead —
no need to touch the Firebase console again for day-to-day updates.

## 4. How pricing works

Nothing is stored as a flat final price. Each product stores **weight**,
**purity**, **making charge** (flat ₹ or % of metal value), **other
charges**, and an optional **wastage %**. `js/pricing.js` combines those with
the live rate from `/rates` to calculate the total, so changing a rate in the
admin panel instantly recalculates every product's price on every page — no
per-product editing needed. A 3% GST line is included by default (standard
for gold jewellery in India); adjust or remove it in the `PRICING_CONFIG`
object at the top of `js/pricing.js`.

## 5. Hosting

Any static host works, since there's no server code — Firebase Hosting
(free), Netlify, Vercel, or GitHub Pages are all fine. If you use Firebase
Hosting: `npm i -g firebase-tools`, then `firebase login`, `firebase init
hosting` (pick this folder as the public directory), and `firebase deploy`.

## 6. Adding real photos

Firebase Storage needs the paid Blaze plan, so this project avoids it. Two
free options for real images:
- **Simplest:** put photo files in `assets/images/` and reference them by
  filename (e.g. `assets/images/necklace-01.jpg`) in the admin panel's Image
  URL field — works with any static host, including Firebase Hosting.
- **Alternative:** upload to a free image host (e.g. Cloudinary's free tier)
  and paste the resulting URL into the same field.

## 7. What's intentionally not built yet

- Image upload *inside* the admin panel (you add an image path/URL by hand —
  avoids needing paid Storage).
- Multi-admin roles — there's one shared admin login by design, matching the
  brief's single-owner scope.
- Any cart/checkout/payment — explicitly out of scope per the brief.

Both are easy to add later without restructuring the database if the
business grows into needing them.
