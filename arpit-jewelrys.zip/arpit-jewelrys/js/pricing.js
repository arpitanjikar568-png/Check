/* =========================================================
   pricing.js — Modular price calculation
   Keeps pricing RULES separate from product DATA, so an
   admin can change a rate once and every product recalculates.
   Add new rules (wastage, GST, discounts) here without
   touching product records or the rendering code.
   ========================================================= */

/**
 * Maps a product's stored "purity" value to a key inside /rates.
 * Extend this if you introduce new metals/purities later
 * (e.g. platinum, 14K gold) — just add a rate in Firebase
 * under /rates and a matching entry here.
 */
const PURITY_TO_RATE_KEY = {
  "22K": "gold22K",
  "22k": "gold22K",
  "22K Gold": "gold22K",
  "18K": "gold18K",
  "18k": "gold18K",
  "18K Gold": "gold18K",
  "Silver": "silver",
  "silver": "silver"
};

/** Optional global rule: GST applied on the subtotal (India: typically 3% on gold jewellery). */
const PRICING_CONFIG = {
  gstPercent: 3,
  applyGst: true
};

function getRatePerGram(purity, rates) {
  const key = PURITY_TO_RATE_KEY[purity] || purity;
  const rate = rates && rates[key];
  return typeof rate === "number" ? rate : 0;
}

/**
 * Calculates a full price breakdown for one product against the
 * live /rates data. Nothing here is hard-coded per product —
 * every number is derived from product fields + current rates.
 *
 * @param {Object} product - fields: weight, purity, makingChargeType
 *   ("percentage" | "flat"), makingCharge, otherCharges, wastagePercent (optional)
 * @param {Object} rates - the live /rates node from Firebase
 * @returns {Object} breakdown + total
 */
function calculatePrice(product, rates) {
  const ratePerGram = getRatePerGram(product.purity, rates);
  const weight = Number(product.weight) || 0;
  const wastagePercent = Number(product.wastagePercent) || 0;

  // Effective weight includes wastage (if the admin sets one).
  const effectiveWeight = weight * (1 + wastagePercent / 100);
  const metalCost = ratePerGram * effectiveWeight;

  const makingChargeType = product.makingChargeType || "flat";
  const makingChargeInput = Number(product.makingCharge) || 0;
  const makingCost = makingChargeType === "percentage"
    ? metalCost * (makingChargeInput / 100)
    : makingChargeInput;

  const otherCharges = Number(product.otherCharges) || 0;

  const subtotal = metalCost + makingCost + otherCharges;

  const gst = PRICING_CONFIG.applyGst
    ? subtotal * (PRICING_CONFIG.gstPercent / 100)
    : 0;

  const total = subtotal + gst;

  return {
    ratePerGram,
    weight,
    wastagePercent,
    metalCost: round2(metalCost),
    makingCost: round2(makingCost),
    otherCharges: round2(otherCharges),
    gstPercent: PRICING_CONFIG.applyGst ? PRICING_CONFIG.gstPercent : 0,
    gst: round2(gst),
    total: round2(total)
  };
}

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function formatINR(amount) {
  return "₹" + Number(amount).toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

// Exposed on window so plain <script> tags (non-module pages) can use it.
window.ArpitPricing = { calculatePrice, formatINR, getRatePerGram, PRICING_CONFIG };
