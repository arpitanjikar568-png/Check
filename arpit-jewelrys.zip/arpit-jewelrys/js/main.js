/* =========================================================
   main.js — homepage interactions
   Nav toggle, FAQ accordion, gallery lightbox.
   Replace the file names in HERO_IMAGES / GALLERY_IMAGES with
   your own photos placed inside assets/images/.
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  /* Nav toggle (mobile) */
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => links.classList.toggle("open"));
    links.querySelectorAll("a").forEach(a =>
      a.addEventListener("click", () => links.classList.remove("open"))
    );
  }

  /* FAQ accordion */
  document.querySelectorAll(".faq-item").forEach(item => {
    const question = item.querySelector(".faq-question");
    question.addEventListener("click", () => {
      const wasOpen = item.classList.contains("open");
      item.parentElement.querySelectorAll(".faq-item").forEach(i => i.classList.remove("open"));
      if (!wasOpen) item.classList.add("open");
    });
  });

  /* Gallery lightbox */
  const lightbox = document.getElementById("lightbox");
  if (lightbox) {
    const lightboxImg = lightbox.querySelector("img");
    document.querySelectorAll(".gallery-grid figure").forEach(fig => {
      fig.addEventListener("click", () => {
        lightboxImg.src = fig.querySelector("img").src;
        lightboxImg.alt = fig.querySelector("img").alt;
        lightbox.classList.add("open");
      });
    });
    lightbox.querySelector(".lightbox-close").addEventListener("click", () => lightbox.classList.remove("open"));
    lightbox.addEventListener("click", (e) => { if (e.target === lightbox) lightbox.classList.remove("open"); });
  }
});
