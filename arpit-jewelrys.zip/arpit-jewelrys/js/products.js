/* =========================================================
   products.js
   Reads /products/{category} and /rates from Firebase Realtime
   Database, renders the product grid, and opens the detail
   view with a live price breakdown. Category ("earrings" or
   "necklaces") is set per page via window.ARPIT_CATEGORY.
   ========================================================= */

import { db } from "./firebase-config.js";
import { ref, onValue } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-database.js";

const category = window.ARPIT_CATEGORY || "earrings";
const grid = document.getElementById("product-grid");
const filterBar = document.getElementById("filter-bar");
const rateStrip = document.getElementById("rate-strip");

let allProducts = [];
let currentRates = {};
let activeFilter = "all";

function setLoading() {
  grid.innerHTML = '<div class="loading-state">Loading the catalogue…</div>';
}

function setEmpty() {
  grid.innerHTML = '<div class="empty-state">No pieces here yet — new designs are added regularly. Please check back soon.</div>';
}

function setError() {
  grid.innerHTML = '<div class="empty-state">We could not reach the catalogue right now. Please refresh the page, or check your Firebase configuration in js/firebase-config.js.</div>';
}

function renderRateStrip(rates) {
  if (!rateStrip) return;
  const entries = [
    ["22K Gold", rates.gold22K],
    ["18K Gold", rates.gold18K],
    ["Silver", rates.silver]
  ].filter(([, v]) => typeof v === "number");

  if (!entries.length) { rateStrip.innerHTML = ""; return; }

  rateStrip.innerHTML = entries
    .map(([label, val]) => `<span>${label}: <strong>${window.ArpitPricing.formatINR(val)}/g</strong></span>`)
    .join("");
}

function renderFilters(products) {
  if (!filterBar) return;
  const purities = Array.from(new Set(products.map(p => p.purity).filter(Boolean)));
  filterBar.innerHTML = "";

  const makeChip = (label, value) => {
    const chip = document.createElement("button");
    chip.className = "filter-chip" + (value === activeFilter ? " active" : "");
    chip.textContent = label;
    chip.addEventListener("click", () => {
      activeFilter = value;
      renderFilters(products);
      renderGrid();
    });
    return chip;
  };

  filterBar.appendChild(makeChip("All pieces", "all"));
  purities.forEach(p => filterBar.appendChild(makeChip(p, p)));
}

function renderGrid() {
  const list = activeFilter === "all"
    ? allProducts
    : allProducts.filter(p => p.purity === activeFilter);

  if (!list.length) { setEmpty(); return; }

  grid.innerHTML = "";
  list.forEach(product => {
    const breakdown = window.ArpitPricing.calculatePrice(product, currentRates);
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <div class="product-media">
        ${!product.available ? '<span class="product-tag unavailable">Currently unavailable</span>' : '<span class="product-tag">In collection</span>'}
        <img src="${product.image || placeholderImage()}" alt="${escapeHtml(product.name || "Jewellery piece")}" loading="lazy">
      </div>
      <div class="product-info">
        <h3>${escapeHtml(product.name || "Untitled piece")}</h3>
        <div class="product-meta">${escapeHtml(product.purity || "")}${product.weight ? " · " + product.weight + "g" : ""}</div>
        <div class="product-price">${window.ArpitPricing.formatINR(breakdown.total)}<small>Inclusive of making charges &amp; GST</small></div>
      </div>
    `;
    card.addEventListener("click", () => openDetail(product, breakdown));
    grid.appendChild(card);
  });
}

function placeholderImage() {
  return "data:image/svg+xml;utf8," + encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'><rect width='400' height='400' fill='%23F1E9D8'/><text x='50%' y='50%' font-family='Georgia' font-size='18' fill='%23B8860B' text-anchor='middle'>Image coming soon</text></svg>`
  );
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[s]));
}

/* ---------- Detail overlay ---------- */
const overlay = document.getElementById("detail-overlay");

function openDetail(product, breakdown) {
  if (!overlay) return;
  overlay.innerHTML = `
    <div class="detail-card">
      <button class="detail-close" aria-label="Close">&times;</button>
      <div class="detail-media">
        <img src="${product.image || placeholderImage()}" alt="${escapeHtml(product.name || "Jewellery piece")}">
      </div>
      <div class="detail-body">
        <h2>${escapeHtml(product.name || "Untitled piece")}</h2>
        <p>${escapeHtml(product.description || "A handcrafted piece from the Arpit Jewelrys collection.")}</p>
        <div class="product-meta">
          ${escapeHtml(product.purity || "")}${product.weight ? " · " + product.weight + "g" : ""}
          ${product.available === false ? " · Currently unavailable" : ""}
        </div>
        <div class="detail-breakdown">
          <div class="row"><span>Metal value (${breakdown.weight}g${breakdown.wastagePercent ? " incl. " + breakdown.wastagePercent + "% wastage" : ""})</span><span>${window.ArpitPricing.formatINR(breakdown.metalCost)}</span></div>
          <div class="row"><span>Making charge</span><span>${window.ArpitPricing.formatINR(breakdown.makingCost)}</span></div>
          ${breakdown.otherCharges ? `<div class="row"><span>Other charges</span><span>${window.ArpitPricing.formatINR(breakdown.otherCharges)}</span></div>` : ""}
          ${breakdown.gstPercent ? `<div class="row"><span>GST (${breakdown.gstPercent}%)</span><span>${window.ArpitPricing.formatINR(breakdown.gst)}</span></div>` : ""}
          <div class="row total"><span>Total</span><span>${window.ArpitPricing.formatINR(breakdown.total)}</span></div>
        </div>
        <p class="detail-note">Price is calculated live from today's metal rate and updates automatically if the rate changes. Please visit or call the store to confirm final pricing before purchase.</p>
        <a class="btn btn-outline" style="margin-top:1rem" href="tel:+918085159312">Call to enquire</a>
      </div>
    </div>
  `;
  overlay.classList.add("open");
  overlay.querySelector(".detail-close").addEventListener("click", closeDetail);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closeDetail(); });
}

function closeDetail() {
  overlay.classList.remove("open");
  overlay.innerHTML = "";
}

/* ---------- Firebase reads ---------- */
setLoading();

onValue(ref(db, "rates"), (snap) => {
  currentRates = snap.val() || {};
  renderRateStrip(currentRates);
  if (allProducts.length) renderGrid();
}, () => setError());

onValue(ref(db, `products/${category}`), (snap) => {
  const data = snap.val() || {};
  allProducts = Object.keys(data).map(id => ({ id, ...data[id] }));
  renderFilters(allProducts);
  renderGrid();
}, () => setError());
