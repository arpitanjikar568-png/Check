/* =========================================================
   admin.js
   Email/password login (Firebase Auth) + write access to
   /rates and /products. Only signed-in users can write —
   configure this in your Realtime Database rules (see README).
   Create the admin's account once, manually, in:
   Firebase Console → Authentication → Users → Add user.
   ========================================================= */

import { db, auth } from "./firebase-config.js";
import { ref, onValue, push, set, remove, update } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-database.js";
import { signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";

const loginScreen = document.getElementById("login-screen");
const adminScreen = document.getElementById("admin-screen");
const loginForm = document.getElementById("login-form");
const loginStatus = document.getElementById("login-status");
const logoutBtn = document.getElementById("logout-btn");
const adminEmail = document.getElementById("admin-email");

onAuthStateChanged(auth, (user) => {
  if (user) {
    loginScreen.style.display = "none";
    adminScreen.style.display = "block";
    adminEmail.textContent = user.email;
    initAdmin();
  } else {
    loginScreen.style.display = "block";
    adminScreen.style.display = "none";
  }
});

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginStatus.textContent = "";
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    loginStatus.textContent = "Login failed — check the email and password.";
    loginStatus.className = "status-msg error";
  }
});

logoutBtn.addEventListener("click", () => signOut(auth));

let initialised = false;
function initAdmin() {
  if (initialised) return;
  initialised = true;

  /* ----- Rates ----- */
  const rateForm = document.getElementById("rate-form");
  onValue(ref(db, "rates"), (snap) => {
    const rates = snap.val() || {};
    document.getElementById("rate-gold22").value = rates.gold22K ?? "";
    document.getElementById("rate-gold18").value = rates.gold18K ?? "";
    document.getElementById("rate-silver").value = rates.silver ?? "";
  });

  rateForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msg = document.getElementById("rate-status");
    try {
      await update(ref(db, "rates"), {
        gold22K: Number(document.getElementById("rate-gold22").value) || 0,
        gold18K: Number(document.getElementById("rate-gold18").value) || 0,
        silver: Number(document.getElementById("rate-silver").value) || 0
      });
      msg.textContent = "Rates updated — product prices will refresh automatically.";
      msg.className = "status-msg success";
    } catch (err) {
      msg.textContent = "Could not update rates: " + err.message;
      msg.className = "status-msg error";
    }
  });

  /* ----- Products ----- */
  const productForm = document.getElementById("product-form");
  const productTableBody = document.querySelector("#product-table tbody");
  const categorySelect = document.getElementById("p-category");
  const editingIdField = document.getElementById("p-id");
  const productStatus = document.getElementById("product-status");

  let productsCache = { earrings: {}, necklaces: {} };

  function renderTable() {
    productTableBody.innerHTML = "";
    Object.entries(productsCache).forEach(([cat, items]) => {
      Object.entries(items || {}).forEach(([id, p]) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${escapeHtml(p.name || "")}</td>
          <td>${cat}</td>
          <td>${escapeHtml(p.purity || "")}</td>
          <td>${p.weight ?? ""}g</td>
          <td>${p.available === false ? "No" : "Yes"}</td>
          <td>
            <button data-action="edit" data-cat="${cat}" data-id="${id}">Edit</button>
            <button data-action="delete" data-cat="${cat}" data-id="${id}">Delete</button>
          </td>
        `;
        productTableBody.appendChild(tr);
      });
    });
  }

  ["earrings", "necklaces"].forEach(cat => {
    onValue(ref(db, `products/${cat}`), (snap) => {
      productsCache[cat] = snap.val() || {};
      renderTable();
    });
  });

  productTableBody.addEventListener("click", (e) => {
    const btn = e.target.closest("button");
    if (!btn) return;
    const { action, cat, id } = btn.dataset;
    if (action === "delete") {
      if (confirm("Remove this product?")) remove(ref(db, `products/${cat}/${id}`));
    }
    if (action === "edit") {
      const p = productsCache[cat][id];
      editingIdField.value = id;
      categorySelect.value = cat;
      document.getElementById("p-name").value = p.name || "";
      document.getElementById("p-purity").value = p.purity || "22K";
      document.getElementById("p-weight").value = p.weight || "";
      document.getElementById("p-making-type").value = p.makingChargeType || "flat";
      document.getElementById("p-making").value = p.makingCharge || "";
      document.getElementById("p-other").value = p.otherCharges || "";
      document.getElementById("p-wastage").value = p.wastagePercent || "";
      document.getElementById("p-image").value = p.image || "";
      document.getElementById("p-description").value = p.description || "";
      document.getElementById("p-available").checked = p.available !== false;
      window.scrollTo({ top: productForm.offsetTop - 20, behavior: "smooth" });
    }
  });

  productForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const cat = categorySelect.value;
    const id = editingIdField.value;
    const payload = {
      name: document.getElementById("p-name").value.trim(),
      purity: document.getElementById("p-purity").value,
      weight: Number(document.getElementById("p-weight").value) || 0,
      makingChargeType: document.getElementById("p-making-type").value,
      makingCharge: Number(document.getElementById("p-making").value) || 0,
      otherCharges: Number(document.getElementById("p-other").value) || 0,
      wastagePercent: Number(document.getElementById("p-wastage").value) || 0,
      image: document.getElementById("p-image").value.trim(),
      description: document.getElementById("p-description").value.trim(),
      available: document.getElementById("p-available").checked
    };
    try {
      if (id) {
        await update(ref(db, `products/${cat}/${id}`), payload);
      } else {
        await set(push(ref(db, `products/${cat}`)), payload);
      }
      productForm.reset();
      editingIdField.value = "";
      productStatus.textContent = "Saved.";
      productStatus.className = "status-msg success";
    } catch (err) {
      productStatus.textContent = "Could not save product: " + err.message;
      productStatus.className = "status-msg error";
    }
  });

  document.getElementById("product-reset").addEventListener("click", () => {
    productForm.reset();
    editingIdField.value = "";
  });
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[s]));
}
